import org.junit.Test;

import java.util.Date;

import static org.junit.Assert.*;

public class AppointmentServiceTest {

    @Test
    public void testAddAppointment() {
        AppointmentService appointmentService = new AppointmentService();
        Date currentDate = new Date();
        Appointment appointment = new Appointment("12345", currentDate, "Test Appointment");

        appointmentService.addAppointment(appointment);

        assertEquals(appointment, appointmentService.getAppointment("12345"));
    }

    @Test
    public void testDeleteAppointment() {
        AppointmentService appointmentService = new AppointmentService();
        Date currentDate = new Date();
        Appointment appointment = new Appointment("12345", currentDate, "Test Appointment");

        appointmentService.addAppointment(appointment);
        appointmentService.deleteAppointment("12345");

        assertNull(appointmentService.getAppointment("12345"));
    }

}
