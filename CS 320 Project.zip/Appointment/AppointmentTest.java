import org.junit.Test;

import java.util.Date;

import static org.junit.Assert.*;

public class AppointmentTest {

    @Test
    public void testAppointmentCreation() {
        Date currentDate = new Date();
        Appointment appointment = new Appointment("12345", currentDate, "Test Appointment");

        assertEquals("12345", appointment.getAppointmentId());
        assertEquals(currentDate, appointment.getAppointmentDate());
        assertEquals("Test Appointment", appointment.getDescription());
    }

}
