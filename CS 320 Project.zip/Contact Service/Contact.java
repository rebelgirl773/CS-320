public class Contact {
    private String contactID;
    private String firstName;
    private String lastName;
    private String phone;
    private String address;

    // Constructor
    public Contact(String contactID, String firstName, String lastName, String phone, String address) {
        // Initialize fields and perform validations
    }

    // Getter and setter methods for each field

    // Additional methods if needed
}
